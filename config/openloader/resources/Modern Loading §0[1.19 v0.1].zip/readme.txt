------------------------------
Owned and created by: Daki "Dawortar" Nate
------------------------------
All Rights Reserved:
✦ This work is under All Rights Reserved license.
------------------------------
Can I use your work in my own creations?
✦ Feel free to give my work a new life for as long as you credit me in the creation you use it in.
✦ When using my work please post a link to an official site.
✦ When crediting my work you can use either "Dawortar" or "Dakinate", both nicknames are associated with me.
------------------------------
For More:
✦ Curse Forge: https://www.curseforge.com/members/dawortar/projects
✦ Planet Minecraft: https://www.planetminecraft.com/member/dawortar/submissions
------------------------------
Support Me:
✦ PayPal: https://www.paypal.com/paypalme/Dawortar
✦ Ko-fi: https://ko-fi.com/dawortar
✦ Patreon: https://www.patreon.com/user?u=122264610
------------------------------
©2024 Dakinate/Dawortar
